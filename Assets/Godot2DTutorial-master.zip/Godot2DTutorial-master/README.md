# Godot2DTutorial
A Complete Godot 2D Game Step By Step

This source code is the complete respository (code, project files and assets) released as part of the tutorial series at http://devga.me/tutorials/Godot2D.  The zip file containing the assets if you want to do this step by step instead of cloning this archive can be [downloaded here](https://github.com/serapth/Godot2DTutorial/raw/master/assets.zip).

There is a 70pg PDF version of the tutorial [available to Patreons](https://www.patreon.com/gamefromscratch) (thanks, by the way!).

It is released under the MIT open source license. The vast majority of art assets in this project were created by [Robert @ Game Developer Studio](https://www.gamedeveloperstudio.com/)
![Project Image](https://pbs.twimg.com/media/Dxx-tCPUYAABhSk.jpg).  
